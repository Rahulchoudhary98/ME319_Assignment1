# Final submission checklist

- [ ] Verify all team member names and roll numbers in the paper.
- [ ] Run the provided script in Octave/MATLAB and inspect its CSV files and plots.
- [ ] Confirm every reported number and figure in the PDF agrees with the reproducible source.
- [ ] Create a public GitHub repository containing this source bundle.
- [ ] Replace the “awaiting team-provided URL” placeholder in the paper with the real repository URL and regenerate the PDF.
- [ ] Ensure the technical paper is at most six pages, excluding the one-page AI appendix.
- [ ] Every team member submits the official confidential peer evaluation form independently.
- [ ] Upload the final PDF through the course submission form.
